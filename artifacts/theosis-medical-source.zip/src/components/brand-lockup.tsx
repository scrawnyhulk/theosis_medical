import { cn } from "@/lib/utils";

export function BrandLockup({
  className,
  fillHeader = false,
}: {
  className?: string;
  fillHeader?: boolean;
}) {
  return (
    <img
      src="/images/header-lockup.png"
      alt="Theosis Medical"
      className={cn(
        "no-outline block w-auto object-contain object-left",
        fillHeader ? "h-full" : "h-14",
        className,
      )}
    />
  );
}
